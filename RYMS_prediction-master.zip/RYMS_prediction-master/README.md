# RYMS_prediction
We have developed a website for diabetes and cancer prediction using machine learning algorithms and the Django Framework. The accuracy rate for diabetes prediction is 78% and for breast cancer it is 97%.
